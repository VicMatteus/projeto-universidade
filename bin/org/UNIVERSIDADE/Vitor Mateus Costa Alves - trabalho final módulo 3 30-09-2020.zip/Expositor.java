package org.UNIVERSIDADE;

public interface Expositor
{
	public String getInfo();
}
